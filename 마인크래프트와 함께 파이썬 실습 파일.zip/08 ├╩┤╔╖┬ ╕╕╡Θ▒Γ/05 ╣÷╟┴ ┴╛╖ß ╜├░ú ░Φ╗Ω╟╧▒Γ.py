from datetime import datetime

dur = 60
start = datetime.now()
print("start buf! :", start)
end = datetime.now()

while((end - start).seconds <= dur):
    end = datetime.now()

print("end buf! :", end)