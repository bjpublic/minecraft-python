from mcpi.minecraft import Minecraft
import time

magic_word = "건물 나와라 뚝딱"

def build_house(x1, y1, z1):
    block = 5
    air = 0
    x2, y2, z2 = x1 + 10, y1 + 10, z1 + 10
    mc.setBlocks(x1, y1, z1, x2, y2, z2, block)
    x1, y1, z1 = x1+1, y1+1, z1+1
    x2, y2, z2 = x2-1, y2-1, z2-1
    mc.setBlocks(x1, y1, z1, x2, y2, z2, air)

mc = Minecraft.create()

while(1):
    chatEvent = mc.events.pollChatPosts()
    if not chatEvent:
        continue
    ce = chatEvent[0]
    if ce.message == magic_word:
        mc.events.pollBlockHits()
    mc.postToChat('select where you want')
    time.sleep(2)
    for hit in mc.events.pollBlockHits():
        if hit.entityId == ce.entityId:
            build_house(hit.pos.x, hit.pos.y, hit.pos.z)