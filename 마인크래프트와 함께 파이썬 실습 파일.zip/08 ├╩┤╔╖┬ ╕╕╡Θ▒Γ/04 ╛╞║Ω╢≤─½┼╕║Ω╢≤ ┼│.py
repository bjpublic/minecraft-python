from mcpi.minecraft import Minecraft
import time
mc = Minecraft.create()
water = 8
air = 0
while(1):
    chatEvent = mc.events.pollChatPosts()

    if not chatEvent:
        continue

    ce = chatEvent[0]

    if ce.message.startswith("아브라카타브라 "):
        magic = ce.message.replace("아브라카타브라 ", "")

        if "홍수" in magic:
            mc.postToChat("Warning!! Flooding!!!")
            pos = mc.entity.getTilePos(ce.entityId)
            mc.setBlocks(pos.x-20, pos.y + 50, pos.z-20, pos.x+20, pos.y + 50, pos.z+20, water)
            time.sleep(60)
            mc.setBlocks(pos.x-20, pos.y + 50, pos.z-20, pos.x+20, pos.y + 50, pos.z+20, air)

        elif magic.startswith("킬 "):
            kill, player_name = magic.split(' ')
            player_id = mc.getPlayerEntityId(player_name)
            pos = mc.entity.getTilePos(player_id)
            mc.entity.setTilePos(player_id, pos.x, pos.y - 500, pos.z)
            mc.postToChat("Go to Narak, " + player_name)