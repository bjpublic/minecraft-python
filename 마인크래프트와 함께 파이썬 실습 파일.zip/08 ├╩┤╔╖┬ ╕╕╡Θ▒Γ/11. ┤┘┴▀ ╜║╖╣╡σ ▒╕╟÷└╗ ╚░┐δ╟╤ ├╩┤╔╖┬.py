from mcpi.minecraft import Minecraft
from datetime import datetime
import threading
import time
sm_Thread = threading.Semaphore(value=5)
sw_flood = False
sw_ice_buff = False
sw_fire_buff = False

magic_flood = "아브라카타브라 홍수"
magic_kill = "아브라카타브라 킬 "
magic_ice_buff = "버프 아이스"
magic_fire_buff = "버프 파이어"
magic_come_home = "건물 나와라 뚝딱"
magic_quit = "quit()"
nick_name = 'gasbugs'

buff_dur = 60 # 버프 동작 시간(초)
air = 0 # 공기 블록 ID
plank = 5 #나무 판자 블록 ID
water = 8 #물 블록 ID
fire = 51 #불 블록 ID
ice = 79 #얼음 블록 ID

mc = Minecraft.create()
player_id = mc.getPlayerEntityId(nick_name)

def flood():
    global sw_flood
    sw_flood = True
    mc = Minecraft.create()
    mc.postToChat("Warning!! Flooding!!!")
    pos = mc.entity.getTilePos(player_id)
    mc.setBlocks(pos.x-20, pos.y + 50, pos.z-20, pos.x+20, pos.y + 50, pos.z+20, water)
    time.sleep(60)
    mc.setBlocks(pos.x-20, pos.y + 50, pos.z-20, pos.x+20, pos.y + 50, pos.z+20, air)
    sm_Thread.release()
    sw_flood = False

def kill_player(message):
    mc = Minecraft.create()
    abrakatabra, kill, target_name = message.split(' ')
    try:
        target_id = mc.getPlayerEntityId(target_name)
    except:
        mc.postToChat("Cannot find the target")
        return
    pos = mc.entity.getTilePos(target_id)
    mc.entity.setTilePos(target_id, pos.x, pos.y - 500, pos.z)
    mc.postToChat("Go to Narak, " + target_name)

def buff_ice():
    global sw_ice_buff
    sw_ice_buff = True
    mc = Minecraft.create()
    # 시작 시간 기록 및 출력
    start = datetime.now()
    start_message = "start buf! : " + str(start)
    mc.postToChat(start_message)

    # 종료 시간이 전이라면 얼음 블록을 설치
    end = datetime.now()
    while((end - start).seconds <= buff_dur):
        pos = mc.entity.getTilePos(player_id) # 사용자 위치 조회
        mc.setBlock(pos.x, pos.y-1, pos.z, ice) # 사용자 아래에 얼음 블록 설치
        end = datetime.now()

    end_message = "end buf! : " + str(end)
    mc.postToChat(end_message)
    sw_ice_buff = False

def buff_fire():
    global sw_fire_buff
    sw_fire_buff = True
    mc = Minecraft.create()

    # 시작 시간 기록 및 출력
    start = datetime.now()
    start_message = "start buf! : " + str(start)
    mc.postToChat(start_message)

    ####################################
    # 종료 시간이 전이라면 얼음 블록을 설치
    end = datetime.now()

    # 이전 사용자 위치 저장
    old_pos = mc.entity.getTilePos(player_id)
    while((end - start).seconds <= buff_dur):
        # 사용자 현재 위치와 이전 위치가 같은지 확인
        pos = mc.entity.getTilePos(player_id)
        if(pos.x == old_pos.x and pos.y == old_pos.y and pos.z == old_pos.z):
            continue

        # 사용자의 현재 위치가 어떤 블록 위인지 확인
        block = mc.getBlock(pos.x, pos.y - 1, pos.z)
        if block == air: # 공기 중에 떠있다면
            continue

        # 이전에 있던 블록에 불 블록 설치
        mc.setBlock(old_pos.x, old_pos.y, old_pos.z, fire)
        old_pos = pos # 현재 위치를 이전 위치로 저장
        end = datetime.now()
    end_message = "end buf! : " + str(end)
    mc.postToChat(end_message)
    sw_fire_buff = False

def come_home():
    mc = Minecraft.create()
    mc.events.pollBlockHits()
    mc.postToChat('select where you want')
    time.sleep(2)
    for hit in mc.events.pollBlockHits():
        if hit.entityId == player_id:
            build_house(hit.pos.x, hit.pos.y, hit.pos.z)

def build_house(x1, y1, z1):
    x2, y2, z2 = x1 + 10, y1 + 10, z1 + 10
    mc.setBlocks(x1, y1, z1, x2, y2, z2, plank)
    x1, y1, z1 = x1+1, y1+1, z1+1
    x2, y2, z2 = x2-1, y2-1, z2-1
    mc.setBlocks(x1, y1, z1, x2, y2, z2, air)


while(1):
    chatEvent = mc.events.pollChatPosts()
    if not chatEvent:
        continue
    for ce in chatEvent:
        if ce.entityId != player_id:
            continue

    message = ce.message.strip()  # 앞 뒤 공백 제거

    if message == magic_flood:
        if sw_flood:
            mc.postToChat('This spell is already running.')
            continue
        sm_Thread.acquire()
        t = threading.Thread(target=flood)
        t.start()
    elif message.startswith(magic_kill):
        sm_Thread.acquire()
        t = threading.Thread(target=kill_player, args=(message,))
        t.start()
    elif message == magic_ice_buff:
        if sw_ice_buff:
            mc.postToChat('This spell is already running.')
            continue
        sm_Thread.acquire()
        t = threading.Thread(target=buff_ice)
        t.start()
    elif message == magic_fire_buff:
        if sw_fire_buff:
            mc.postToChat('This spell is already running.')
            continue
        sm_Thread.acquire()
        t = threading.Thread(target=buff_fire)
        t.start()
    elif message == magic_come_home:
        sm_Thread.acquire()
        t = threading.Thread(target=come_home)
        t.start()
    elif message == magic_quit:
        exit()