from mcpi.minecraft import Minecraft
from datetime import datetime

ice = 79 #얼음 블록 ID
dur = 60 # 동작 시간 (초)

mc = Minecraft.create()
player_id = mc.getPlayerEntityId('gasbugs')

# 시작 시간 기록 및 출력
start = datetime.now()
start_message = "start buf! : " + str(start)
print(start_message)
mc.postToChat(start_message)

# 종료 시간이 전이라면 얼음 블록을 설치
end = datetime.now()

while((end - start).seconds <= dur):
    pos = mc.entity.getTilePos(player_id) # 사용자 위치 조회
    mc.setBlock(pos.x, pos.y-1, pos.z, ice) # 사용자 아래에 얼음 블록 설치
    end = datetime.now()

end_message = "end buf! : " + str(end)
print(end_message)
mc.postToChat(end_message)