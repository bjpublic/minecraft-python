from mcpi.minecraft import Minecraft
from datetime import datetime

fire = 51 #불 블록 ID
dur = 60 # 동작 시간 (초)
air = 0

mc = Minecraft.create()
player_id = mc.getPlayerEntityId('gasbugs')

# 시작 시간 기록 및 출력
start = datetime.now()
start_message = "start buf! : " + str(start)
print(start_message)
mc.postToChat(start_message)

####################################
# 종료 시간이 전이라면 얼음 블록을 설치
end = datetime.now()

# 이전 사용자 위치 저장
old_pos = mc.entity.getTilePos(player_id)
while((end - start).seconds <= dur):
    # 사용자 현재 위치와 이전 위치가 같은지 확인
    pos = mc.entity.getTilePos(player_id)
    if(pos.x == old_pos.x and pos.y == old_pos.y and pos.z == old_pos.z):
        continue

    # 사용자의 현재 위치가 어떤 블록 위인지 확인
    block = mc.getBlock(pos.x, pos.y - 1, pos.z)
    print(pos.x, pos.y, pos.z, block)
    if block == air: # 공기 중에 떠있다면
        continue

    # 이전에 있던 블록에 불 블록 설치
    mc.setBlock(old_pos.x, old_pos.y, old_pos.z, fire)
    old_pos = pos # 현재 위치를 이전 위치로 저장
    end = datetime.now()

end_message = "end buf! : " + str(end)
print(end_message)
mc.postToChat(end_message)