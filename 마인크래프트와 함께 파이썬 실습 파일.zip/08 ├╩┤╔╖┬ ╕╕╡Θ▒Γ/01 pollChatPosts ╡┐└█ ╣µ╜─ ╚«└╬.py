from mcpi.minecraft import Minecraft

mc = Minecraft.create()

while(1):
    chatEvent = mc.events.pollChatPosts()

    if not chatEvent:
        continue

    ce = chatEvent[0]
    print(ce.message)
    print(ce.entityId)