from mcpi.minecraft import Minecraft
mc = Minecraft.create()
#player_id = mc.getPlayerEntityId('gasbugs')
#pos = mc.entity.getTilePos(player_id)

while(1):
    chatEvent = mc.events.pollChatPosts()
    if not chatEvent:
        continue

    ce = chatEvent[0]

    if ce.message.startswith("아브라카타브라 "):
        magic = ce.message.replace("아브라카타브라 ", "")
        print(magic)
        break