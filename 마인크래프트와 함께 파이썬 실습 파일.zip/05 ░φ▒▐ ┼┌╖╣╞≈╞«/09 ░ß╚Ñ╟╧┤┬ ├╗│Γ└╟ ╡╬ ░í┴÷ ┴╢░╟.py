person1 = ['car', 'house']
person2 = ['car']
person3 = ['house']
person4 = []
condition1 = 'car'
condition2 = 'house'
# 청년은 둘 다 가진 사람을 원한다.
if condition1 in person1 and condition2 in person1:
    print('person1은 조건에 만족합니다.')
else:
    print('person1은 조건에 만족하지 않습니다.')
if condition1 in person2 and condition2 in person2:
    print('person2은 조건에 만족합니다.')
else:
    print('person2은 조건에 만족하지 않습니다.')
if condition1 in person3 and condition2 in person3:
    print('person3은 조건에 만족합니다.')
else:
    print('person3은 조건에 만족하지 않습니다.')
if condition1 in person4 and condition2 in person4:
    print('person4은 조건에 만족합니다.')
else:
    print('person4은 조건에 만족하지 않습니다.')