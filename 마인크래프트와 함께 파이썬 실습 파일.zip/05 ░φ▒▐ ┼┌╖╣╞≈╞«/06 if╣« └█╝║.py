condition1 = 1<2
if condition1:
    print("1<2: 참")
    condition2 = 1>2
if condition2:
    print("1>2: 참")