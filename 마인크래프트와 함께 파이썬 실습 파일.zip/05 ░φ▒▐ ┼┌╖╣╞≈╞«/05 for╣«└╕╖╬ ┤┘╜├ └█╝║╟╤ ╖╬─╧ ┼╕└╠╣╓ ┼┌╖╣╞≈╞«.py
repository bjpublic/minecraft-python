import time
from mcpi.minecraft import Minecraft

def go_short(mc, x, y, z):
    _id = mc.getPlayerEntityId("gasbugs")
    _x, _y, _z = mc.entity.getPos(_id)
    mc.entity.setPos(_id, _x + z, _y + y, _z + z)

mc = Minecraft.create()
mc.postToChat("Start countdown.")

for s in range(10, -1, -1): # 10에서 0까지 -1씩
    mc.postToChat("{}s".format(s))
    time.sleep(1)

for count in range(10): # 위로 이동 10번반복
    go_short(mc, 0, 10, 0)