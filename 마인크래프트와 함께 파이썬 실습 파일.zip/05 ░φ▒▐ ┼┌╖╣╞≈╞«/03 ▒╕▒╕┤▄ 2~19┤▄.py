# 구구단 2단부터 19단까지
for i in range(2,20):
    for j in range(1, 20):
        print("{} x {} = {}".format(i,j,i*j))