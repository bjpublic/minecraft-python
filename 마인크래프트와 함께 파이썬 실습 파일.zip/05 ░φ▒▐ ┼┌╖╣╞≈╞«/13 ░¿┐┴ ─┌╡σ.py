from mcpi.minecraft import Minecraft

mc = Minecraft.create()

prison = [-13578, 70, 4941]
prison_area1 = [-13580, 69, 4939]
prison_area2 = [-13577, 72, 4944]

# 게임에서 mcpi로 보낼 때 사용하는 함수
def corr_pos_to_mcpi(x, y, z):
    x -= 91
    y -= 64
    z -= 255
    return x, y, z
# mcpi에서 게임으로 보낼때 사용하는 함수
def corr_pos_to_game(x, y, z):
    x += 91
    y += 64
    z += 255
    return x, y, z
def go_prison(mc):
    x, y, z = 249, 71, 160
    x, y, z = corr_pos_to_mcpi(x, y, z)
    _id = mc.getPlayerEntityId("gasbugs")
    prison_pos = corr_pos_to_mcpi(prison[0], prison[1], prison[2])
    mc.entity.setPos(_id, prison_pos)

# 플레이어 ID 불러오기
player_id = mc.getPlayerEntityId('gasbugs')

while(True):
    #1. 캐릭터 위치 파악
    pos = mc.entity.getTilePos(player_id)
    pos = corr_pos_to_game(pos.x, pos.y, pos.z)
    #2. 텔레포트가 필요한 위치인지 확인
    print(pos)
    condition1 = prison_area1[0] <= pos[0] and prison_area1[1] <= pos[1] and prison_area1[2] <= pos[2]
    condition2 = prison_area2[0] >= pos[0] and prison_area2[1] >= pos[1] and prison_area2[2] >= pos[2]
    if not (condition1 and condition2):
        #3. 캐릭터가 텔레포트를 해야하는 위치라면 해당 캐릭터를 감옥으로 텔레포트
        go_prison(mc)
    #4. 다시 1번으로 이동