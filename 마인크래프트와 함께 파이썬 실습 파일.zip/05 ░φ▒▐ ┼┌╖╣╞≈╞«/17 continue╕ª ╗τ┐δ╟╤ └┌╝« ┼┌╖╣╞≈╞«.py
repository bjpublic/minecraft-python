from mcpi.minecraft import Minecraft
mc = Minecraft.create()
player_id = mc.getPlayerEntityId('bh20125')
while(1):
    pos = mc.entity.getPos(player_id)
    player_list = mc.getPlayerEntityIds()
    for player in player_list:
        if player == player_id:
            continue
        mc.entity.setPos(player, pos.x, pos.y, pos.z)