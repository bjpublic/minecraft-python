toy = '로봇'
if toy == '인형':
    print("인형이다!")
elif toy == '로봇':
    print('로봇이다!')
elif toy == '비행기':
    print('비행기다!')
else:
    print("여기 중에 없다.")