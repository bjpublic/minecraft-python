count = 0
while(True): # 무한으로 돌아가는 루프
    print(count)
    count += 1 # 카운트 1씩 증가