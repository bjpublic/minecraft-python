import time
count = 0
for i in [1,2,3]:
    print('{}초가 지났습니다.'.format(count))
    time.sleep(count)
    count += i
print('{}초가 지났습니다.'.format(count))