count = 0
while(count != 10): # 카운트가 10이되면 종료
    print(count)
    count += 1 # 카운트 1씩 증가