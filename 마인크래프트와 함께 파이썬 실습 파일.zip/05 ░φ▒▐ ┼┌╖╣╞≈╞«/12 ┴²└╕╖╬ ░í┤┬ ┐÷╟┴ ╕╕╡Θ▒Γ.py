from mcpi.minecraft import Minecraft

mc = Minecraft.create()
go_home_pos = [-13610, 76, 4929] # 집으로 이동하는 워프 좌표
home_pos = [-13599, 70, 4934] # 집의 좌표

# 게임에서 mcpi로 보낼때 사용하는 함수
def corr_pos_to_mcpi(x, y, z):
    x -= 91
    y -= 64
    z -= 255
    return x, y, z

# mcpi에서 게임으로 보낼때 사용하는 함수
def corr_pos_to_game(x, y, z):
    x += 91
    y += 64
    z += 255
    return x, y, z

def go_home(mc):
    x, y, z = 249, 71, 160
    x, y, z = corr_pos_to_mcpi(x, y, z)
    _id = mc.getPlayerEntityId("gasbugs")
    mcpi_home = corr_pos_to_mcpi(home_pos[0], home_pos[1], home_pos[2])
    mc.entity.setPos(_id, mcpi_home)


# 플레이어 ID 불러오기
player_id = mc.getPlayerEntityId('gasbugs')

while(True):
    #1. 캐릭터 위치 파악
    pos = mc.entity.getTilePos(player_id)
    pos = corr_pos_to_game(pos.x, pos.y, pos.z)
    #2. 텔레포트가 필요한 위치인지 확인
    if pos[0] == go_home_pos[0] and pos[1] == go_home_pos[1] and pos[2] == go_home_pos[2]:
        #3. 캐릭터가 텔레포트를 해야하는 위치라면 해당 캐릭터를 집으로 텔레포트
        go_home(mc)
    #4. 다시 1번으로 이동