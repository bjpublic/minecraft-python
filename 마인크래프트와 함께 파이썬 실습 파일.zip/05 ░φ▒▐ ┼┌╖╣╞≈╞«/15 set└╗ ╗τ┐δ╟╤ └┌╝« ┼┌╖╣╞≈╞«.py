from mcpi.minecraft import Minecraft
mc = Minecraft.create()
player_id = mc.getPlayerEntityId('bh20125')

while(1):
    pos = mc.entity.getPos(player_id)
    player_list = set(mc.getPlayerEntityIds())
    player_list -= set([player_id])
    for player in player_list:
        mc.entity.setPos(player, pos.x, pos.y, pos.z)