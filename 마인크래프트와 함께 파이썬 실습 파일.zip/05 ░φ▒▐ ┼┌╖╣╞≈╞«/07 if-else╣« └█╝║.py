condition2 = 1>2
if condition2:
    print("1>2: 참")
else:
    print("1>2: 거짓")