# a, b, c, d 토너먼트 게임
for i in ['a', 'b', 'c', 'd']:
    for j in ['a', 'b', 'c', 'd']:
        print("{} vs {}".format(i, j))