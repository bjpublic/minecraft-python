count = 0
for i in range(10000): #[0,..., 9999]
    i = str(i)
    if '8' not in i:
        continue
    print(i)
    count += i.count('8')
print(count)