for i in range(1,10):
    print("{} x {} = {}".format(2, i, 2*i))