from mcpi.minecraft import Minecraft
mc = Minecraft.create()
x = 207
y = 72
z = 130
wool10 = (35,10) # 양털 ID 35번의 10번 데이터
mc.setBlock(x-80, y-64, z-248, wool10)
print("Set!!!")