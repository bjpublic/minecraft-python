from mcpi.minecraft import Minecraft
mc = Minecraft.create()
_id = mc.getPlayerEntityId('gasbugs')
pos = mc.entity.getPos(_id)
print(pos.x + 80)
print(pos.y + 64)
print(pos.z + 248)