from mcpi.minecraft import Minecraft
mc = Minecraft.create()

mc = Minecraft.create()
pumpkin = 91 # 잭 오 랜턴
length = 20 # 정육면체 각 변의 길이
# 플레이어 데이터 얻기
_id = mc.getPlayerEntityId('gasbugs')
pos = mc.entity.getTilePos(_id)
print(pos)
# 플레이어 머리 위에 잭 오 랜턴 놓기
mc.setBlocks(pos.x, pos.y + 10, pos.z, pos.x + length, pos.y + 10 + length, pos.z + length, pumpkin)
print("Set!!!")