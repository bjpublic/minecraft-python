from mcpi.minecraft import Minecraft
mc = Minecraft.create()
gold = 41
# 플레이어 데이터 얻기
_id = mc.getPlayerEntityId('gasbugs')
pos = mc.entity.getTilePos(_id)
print(pos)
# 플레이어 옆에 금 놓기
mc.setBlock(pos.x+1, pos.y, pos.z, gold)
print("Set!!!")