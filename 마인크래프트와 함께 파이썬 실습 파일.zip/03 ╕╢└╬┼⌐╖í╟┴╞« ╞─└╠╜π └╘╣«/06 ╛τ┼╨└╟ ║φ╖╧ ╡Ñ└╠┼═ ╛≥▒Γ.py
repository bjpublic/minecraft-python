from mcpi.minecraft import Minecraft
mc = Minecraft.create()
x = 207
y = 72
z = 129
data = mc.getBlockWithData(x-80, y-64,z-248)
print(data)