print("Hello, Python")

import os
os.system("calc")