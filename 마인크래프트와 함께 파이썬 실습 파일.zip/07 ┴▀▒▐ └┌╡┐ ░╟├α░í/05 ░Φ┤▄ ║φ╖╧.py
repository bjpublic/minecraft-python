from mcpi.minecraft import Minecraft

oak_stair = 53 # 참나무 계단 블록

mc = Minecraft.create()
player_id = mc.getPlayerEntityId('gasbugs')
pos = mc.entity.getTilePos(player_id)

# 기준점 세팅
x = pos.x + 1
y = pos.y
z = pos.z

for status in range(16): # status 0부터 15까지
    mc.setBlock(x, y, z, oak_stair, status)
    x += 1