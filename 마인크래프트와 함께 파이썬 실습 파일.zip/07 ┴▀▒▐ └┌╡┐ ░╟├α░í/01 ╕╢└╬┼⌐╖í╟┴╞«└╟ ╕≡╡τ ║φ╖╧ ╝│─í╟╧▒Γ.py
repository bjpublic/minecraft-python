from mcpi.minecraft import Minecraft
import time

mc = Minecraft.create()
player_id = mc.getPlayerEntityId('gasbugs')
pos = mc.entity.getTilePos(player_id)

soil = 2 # 흙 블록

# 블록 생성 위치는 캐릭터 현재 위치보다 y축으로 5만큼 위
pos.y += 5

for blockCode in range(256): # 블록의 ID는 0부터 255까지 존재
    for blockState in range(16): # 블록의 상태는 0부터 15까지 존재
        #흙 블록 설치
        mc.setBlock(pos.x, pos.y-1, pos.z + blockState, soil)
        # 흙 블록 위에 다양한 종류의 블록 설치
        mc.setBlock(pos.x, pos.y, pos.z + blockState, blockCode, blockState)
    pos.x += 1 # x축으로 1만큼 이동 (블록코드마다 한줄씩 이동)
    time.sleep(0.01)