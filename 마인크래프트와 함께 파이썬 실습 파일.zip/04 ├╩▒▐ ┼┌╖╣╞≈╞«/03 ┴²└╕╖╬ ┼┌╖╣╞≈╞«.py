# 게임에서 mcpi로 보낼때 사용하는 함수
def corr_pos_to_mcpi(x, y, z):
    x -= 80
    y -= 64
    z -= 248
    return x, y, z

# mcpi에서 게임으로 보낼때 사용하는 함수
def corr_pos_to_game(x, y, z):
    x += 80
    y += 64
    z += 248
    return x, y, z

def go_home(mc):
    x, y, z = 249, 71, 160
    x, y, z = corr_pos_to_mcpi(x, y, z)
    _id = mc.getPlayerEntityId("gasbugs")
    mc.entity.setPos(_id, x, y, z)

from mcpi.minecraft import Minecraft

mc = Minecraft.create()
go_home(mc)