# 게임에서 mcpi로 보낼때 사용하는 함수
def corr_pos_to_mcpi(x, y, z):
    x -= 92
    y -= 64
    z -= 256
    return x, y, z

# mcpi에서 게임으로 보낼때 사용하는 함수
def corr_pos_to_game(x, y, z):
    x += 92
    y += 64
    z += 256
    return x, y, z

from mcpi.minecraft import Minecraft

mc = Minecraft.create()
x, y, z = -13593, 0, 4928
_x, _y, _z = corr_pos_to_mcpi(x, y, z) # mcpi로 쓸 수 있게 변환
_y = mc.getHeight(_x,_z) # mcpi가 y의 좌표를 가져옴
print(corr_pos_to_game(_x, _y, _z)) # 게임 상의 좌표로 출력