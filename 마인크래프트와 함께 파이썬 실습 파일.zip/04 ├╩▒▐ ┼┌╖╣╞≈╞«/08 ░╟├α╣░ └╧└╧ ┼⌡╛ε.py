import time
from mcpi.minecraft import Minecraft

# 게임에서 mcpi로 보낼때 사용하는 함수
def corr_pos_to_mcpi(x, y, z):
    x -= 92
    y -= 64
    z -= 256
    return x, y, z

# mcpi에서 게임으로 보낼때 사용하는 함수
def corr_pos_to_game(x, y, z):
    x += 92
    y += 64
    z += 256
    return x, y, z

def go_tour(mc, x, y, z, str1):
    mc.postToChat("Welcome to "+ str1 + ".")
    x, y, z = corr_pos_to_mcpi(x, y, z)
    y = mc.getHeight(x, z)
    _id = mc.getPlayerEntityId("gasbugs")
    mc.entity.setPos(_id, x, y, z)
    mc.postToChat("You can tour this site for 1min.")
    time.sleep(60)
    mc.postToChat("We move to next in 5sec")
    time.sleep(5)


mc = Minecraft.create()
mc.postToChat("Let's start 1 day tour.")
time.sleep(5)
go_tour(mc, -13624, 0, 3080, "Mansion")
go_tour(mc, -13304, 0, 3672, "Mineshaft")
go_tour(mc, -13304, 0, 5000, "Monument")
go_tour(mc, -13608, 0, 4952, "Stronghold")
go_tour(mc, -13624, 0, 3400, "Temple")
go_tour(mc, -13576, 0, 3288, "Village")