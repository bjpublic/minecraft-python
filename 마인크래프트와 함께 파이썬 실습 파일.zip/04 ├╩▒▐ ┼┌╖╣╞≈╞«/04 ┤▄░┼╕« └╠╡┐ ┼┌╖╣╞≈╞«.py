from mcpi.minecraft import Minecraft

def go_short(mc, x, y, z):
    _id = mc.getPlayerEntityId("gasbugs")
    _x, _y, _z = mc.entity.getPos(_id)
    mc.entity.setPos(_id, _x + z, _y + y, _z + z)

mc = Minecraft.create()
go_short(mc, 10, 10, 10)