# add1 함수 선언
def add1(a, b): # 함수 사용 시 a와 b를 전달
    c = a + b
    return c # a와 b를 더한 값을 리턴
# add1 함수 실행
print(add1(1, 3)) # a에는 1 b에는 2 전달