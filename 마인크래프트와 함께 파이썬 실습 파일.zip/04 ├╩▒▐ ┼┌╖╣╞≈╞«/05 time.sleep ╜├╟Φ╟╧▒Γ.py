import time
print("0초가 지났습니다.")
time.sleep(1)
print("1초가 지났습니다.")
time.sleep(2)
print("3초가 지났습니다.")
time.sleep(3)
print("6초가 지났습니다.")