import mcpi.minecraft
import time
mc = mcpi.minecraft.Minecraft.create()
log = [17, 162]

def growTree(pos, data):
    for i in range(1,100):
        mc.setBlock(pos.x, pos.y+i, pos.z, data)

while True:
    hits = mc.events.pollBlockHits()
    for hit in hits:
        data = mc.getBlockWithData(hit.pos.x, hit.pos.y, hit.pos.z)
        if data.id in log:
            growTree(hit.pos, data)
        else:
            mc.postToChat("This is not wood: " + str(data.id))
    time.sleep(0.1)