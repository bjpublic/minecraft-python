from mcpi.minecraft import Minecraft

mc = Minecraft.create()

#1. 플레이어의 위치 파악하기
player_id = mc.getPlayerEntityId('gasbugs')
pos = mc.entity.getTilePos(player_id)
block = 2
air = 0

#2. 플레이어의 위치에서 x로 5만큼 이동한 지점에 건설 좌표 설정
pos.x += 5

x1, y1, z1 = pos.x, pos.y, pos.z
x2, y2, z2 = pos.x + 10, pos.y + 10, pos.z + 10
mc.setBlocks(x1, y1, z1, x2, y2, z2, block)
x1, y1, z1 = x1+1, y1+1, z1+1
x2, y2, z2 = x2-1, y2-1, z2-1
mc.setBlocks(x1, y1, z1, x2, y2, z2, air)