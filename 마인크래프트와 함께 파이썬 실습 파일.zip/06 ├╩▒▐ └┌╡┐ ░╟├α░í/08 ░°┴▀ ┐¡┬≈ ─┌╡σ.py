from mcpi.minecraft import Minecraft

mc = Minecraft.create()
player_id = mc.getPlayerEntityId('gasbugs')
pos = mc.entity.getTilePos(player_id)

soil = 2 # 흙 블록
golden_rail = 27 # 전동 레일
detector_rail = 28 # 탐지 레일
rail = 66 # 레일
activator_rail = 157# 활성화 레일

#1. 플레이어의 위치로부터 y축으로 위쪽에 20만큼 좌표에 건설 지점을 설정
pos.y += 20

#2. 건설 지점에서부터 x축으로 100 x 1만큼 지역에 흙 설치
mc.setBlocks(pos.x, pos.y, pos.z, pos.x+100, pos.y, pos.z, soil)

#3. x축으로 100움직인 지점에서 z좌표로 100만큼 흙 설치
pos.x += 100
mc.setBlocks(pos.x, pos.y, pos.z, pos.x, pos.y, pos.z+100, soil)

#4. z축으로 100움직인 지점에서 x좌표로 -100만큼 흙 설치
pos.z += 100
mc.setBlocks(pos.x, pos.y, pos.z, pos.x-100, pos.y, pos.z, soil)

#5. x축으로 -100움직인 지점에서 z좌표로 -100만큼 흙 설치
pos.x -= 100
mc.setBlocks(pos.x, pos.y, pos.z, pos.x, pos.y, pos.z-100, soil)
pos.z -= 100 #건설 지점으로 돌아옴

#6. y축으로 1만큼 올라간 뒤 설치된 흙 위에 레일 설치
pos.y += 1

#7. 레일을 설치할 때는 탐지 레일과 전동 레일을 번갈아 가며 설치
for i in range(100):
    if i % 2 == 0: # 2로 나눠서 0으로 떨어지면 (짝수라면)
        mc.setBlock(pos.x+i, pos.y, pos.z, golden_rail)
    else:
        mc.setBlock(pos.x+i, pos.y, pos.z, detector_rail)

pos.x += 100
for i in range(100):
    if i % 2 == 0:
        mc.setBlock(pos.x, pos.y, pos.z+i, golden_rail)
    else:
        mc.setBlock(pos.x, pos.y, pos.z+i, detector_rail)

pos.z += 100
for i in range(100):
    if i % 2 == 0:
        mc.setBlock(pos.x-i, pos.y, pos.z, golden_rail)
    else:
        mc.setBlock(pos.x-i, pos.y, pos.z, detector_rail)

pos.x -= 100
for i in range(100):
    if i % 2 == 0:
        mc.setBlock(pos.x, pos.y, pos.z - i, golden_rail)
    else:
        mc.setBlock(pos.x, pos.y, pos.z - i, detector_rail)

pos.z -= 100
# 8.코너에는 레일을 설치
mc.setBlock(pos.x, pos.y, pos.z, rail)
mc.setBlock(pos.x, pos.y, pos.z + 100, rail)
mc.setBlock(pos.x + 100, pos.y, pos.z, rail)
mc.setBlock(pos.x + 100, pos.y, pos.z + 100, rail)