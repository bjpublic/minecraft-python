from mcpi.minecraft import Minecraft

mc = Minecraft.create()

#1. 플레이어의 위치 파악하기
player_id = mc.getPlayerEntityId('gasbugs')
pos = mc.entity.getTilePos(player_id)
block = 2

#2. 플레이어의 위치에서 x로 5만큼 이동한 지점에 건설 좌표 설정
pos.x += 5

for ii in range(10): #7
    #3. 좌표로 설정된 부분으로부터 x로 1만큼씩 10번 이동하며 블록 배치
    for i in range(10):
        mc.setBlock(pos.x, pos.y, pos.z, block)
        print(pos.x, pos.y, pos.z)
        pos.x += 1

    #4. z로 1만큼씩 10번 이동하며 블록 배치
    for i in range(10):
        mc.setBlock(pos.x, pos.y, pos.z, block)
        print(pos.x, pos.y, pos.z)
        pos.z += 1

    #5. x로 -1만큼씩 10번 이동하며 블록 배치
    for i in range(10):
        mc.setBlock(pos.x, pos.y, pos.z, block)
        print(pos.x, pos.y, pos.z)
        pos.x -= 1

    #6. z로 -1만큼씩 10번 이동하며 블록 배치
    for i in range(10):
        mc.setBlock(pos.x, pos.y, pos.z, block)
        print(pos.x, pos.y, pos.z)
        pos.z -= 1
    pos.y += 1 #7