import mcpi.minecraft
import time

mc = mcpi.minecraft.Minecraft.create()
gold = 41
while True:
    hits = mc.events.pollBlockHits()
    for hit in hits:
        mc.setBlock(hit.pos.x, hit.pos.y, hit.pos.z, gold)
    time.sleep(0.1)