import mcpi.minecraft
import time
import random

mc = mcpi.minecraft.Minecraft.create()

log = [17, 162] #나무
ladder = 65 #사다리
leaves = 18 # 잎

def growTree(pos, data):
#잎 설치
    for i in range(100):
        # 잎의 너비와 길이 결정
        h = random.randint(0, 3) # 0~3 사이의 숫자 생성

        w = random.randint(0, 3) # 0~3 사이의 숫자 생성
        mc.setBlocks(pos.x-h, pos.y+i, pos.z-w,
        pos.x+h, pos.y+i, pos.z+w, leaves)

    #나무 설치
    mc.setBlocks(pos.x-1, pos.y-20, pos.z-1, pos.x+1, pos.y+100, pos.z+1, data)
    #사다리 설치
    mc.setBlocks(pos.x-2, pos.y-20, pos.z, pos.x-2, pos.y+100, pos.z, ladder,4)

while True:
    hits = mc.events.pollBlockHits()
    for hit in hits:
        data = mc.getBlockWithData(hit.pos.x, hit.pos.y, hit.pos.z)
        if data.id in log:
            growTree(hit.pos, data)
        else:
            mc.postToChat("This is not wood: " + str(data.id))
    time.sleep(0.1)