from mcpi.minecraft import Minecraft
mc = Minecraft.create()
player_id = mc.getPlayerEntityId('gasbugs')
pos = mc.entity.getTilePos(player_id)

air = 0 # 공기 블록
torch = 50 # 횃불 블

#1. 건설 기준점 설치
pos.x += 1
pos.y -= 1
for i in range(200):
    # 2. 10x5x10의 빈 공간 할당
    mc.setBlocks(pos.x, pos.y, pos.z, pos.x + 10, pos.y + 5, pos.z + 10, air)

    # 3. 굴 내부에 횃불 설치
    mc.setBlocks(pos.x, pos.y, pos.z + 2, pos.x + 10, pos.y, pos.z + 2, torch)
    mc.setBlocks(pos.x, pos.y, pos.z + 7, pos.x + 10, pos.y, pos.z + 7, torch)

    # 4. 건설 기준점을 x축으로 10만큼 y축으로 -1만큼 이동
    pos.x += 10
    pos.y -= 1
    # 5. 다시 2번으로 이동

# 6. 2~5를 200번 반복