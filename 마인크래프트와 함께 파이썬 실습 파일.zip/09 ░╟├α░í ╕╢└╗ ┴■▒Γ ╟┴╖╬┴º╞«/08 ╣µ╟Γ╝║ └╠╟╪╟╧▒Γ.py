from mcpi.minecraft import Minecraft
import block2
import time

def getRotationPos(mc, player_id):
    rotation = abs(mc.entity.getRotation(player_id))
    print(rotation)
    if 337.5 <= rotation or rotation < 22.5:
        return 0, 1
    elif 22.5 <= rotation and rotation < 67.5:
        return 1, 1
    elif 67.5 <= rotation and rotation < 112.5:
        return 1, 0
    elif 112.5 <= rotation and rotation < 157.5:
        return 1, -1
    elif 157.5 <= rotation and rotation < 202.5:
        return 0, -1
    elif 202.5 <= rotation and rotation < 247.5:
        return -1, -1
    elif 247.5 <= rotation and rotation < 292.5:
        return -1, 0
    elif 292.5 <= rotation and rotation < 337.5:
        return -1, +1

def fire(mc, pos):
    x, z = getRotationPos(mc)
    pos.y += 1
    for i in range(10):
        pos.x += x
        pos.z += z
        mc.setBlock(pos.x, pos.y, pos.z, block2.Fire)
        time.sleep(0.001)

name = 'gasbugs'
mc = Minecraft.create()
player_id = mc.getPlayerEntityId(name)

while (1):
    chatEvent = mc.events.pollChatPosts()

    if not chatEvent:
        continue

    ce = chatEvent[0]
    command = ce.message.split()

    if command[0] in '파이어':
        mc.events.pollBlockHits()
        mc.postToChat('select where you want')
        time.sleep(2)
        for hit in mc.events.pollBlockHits():
            if hit.entityId == ce.entityId:
                fire(mc, hit.pos)
