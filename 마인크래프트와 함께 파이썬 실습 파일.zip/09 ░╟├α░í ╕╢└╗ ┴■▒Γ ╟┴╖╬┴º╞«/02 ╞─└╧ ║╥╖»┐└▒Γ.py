f = open('test.txt', 'r')
data = f.read()
print(data)
f.close()