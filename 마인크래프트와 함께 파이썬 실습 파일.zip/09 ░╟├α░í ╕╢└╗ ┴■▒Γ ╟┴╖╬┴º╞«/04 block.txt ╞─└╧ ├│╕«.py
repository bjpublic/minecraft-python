f = open('block.txt', 'r')
data = ''
tmp = ''
for line in f.readlines():
    if line.startswith('('):
        continue
    if line[0].isdigit():
        tmp = ' = '
        line = line.replace(':', ',')
        tmp += line.strip()
    if line[0].isalpha():
        line = line.replace(' ', '_')
        line = line.replace('-', '_')
        line = line.replace('(', '')
        line = line.replace(')', '')
        line = line.replace("'", '')
        data += line.strip() + tmp + '\n'
f.close()

f = open('block2.py', 'w')
f.write(data)
f.close()