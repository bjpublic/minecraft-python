import block2
print(block2.Air)