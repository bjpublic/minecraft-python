from block2 import *
import time
import random

def getRotationPos(mc, player_id):
    rotation = abs(mc.entity.getRotation(player_id))
    print(rotation)
    if 337.5 <= rotation or rotation < 22.5:
        return 0, 1
    elif 22.5 <= rotation and rotation < 67.5:
        return 1, 1
    elif 67.5 <= rotation and rotation < 112.5:
        return 1, 0
    elif 112.5 <= rotation and rotation < 157.5:
        return 1, -1
    elif 157.5 <= rotation and rotation < 202.5:
        return 0, -1
    elif 202.5 <= rotation and rotation < 247.5:
        return -1, -1
    elif 247.5 <= rotation and rotation < 292.5:
        return -1, 0
    elif 292.5 <= rotation and rotation < 337.5:
        return -1, +1

def build_road(mc, player_id, pos, command):
    x, z = getRotationPos(mc, player_id)

    try :
        print(command)
        width, length = int(command[0]), int(command[1])
    except:
        width, length = 2, 10

    for i in range(length):
        pos.x += x
        pos.z += z
        mc.setBlocks(pos.x - width//2, pos.y, pos.z - width//2,
                         pos.x + width//2, pos.y, pos.z + width//2, Stone)
        mc.setBlocks(pos.x - width//2, pos.y+1, pos.z - width//2,
                         pos.x + width//2, pos.y+2, pos.z + width//2, Air)

def build_watchtop(mc, player_id, pos, command):
    x, z = getRotationPos(mc, player_id)
    if 0 not in [x, z]:
        mc.postToChat("Failed")
        return False

    try :
        print(command)
        width, length = int(command[0]), int(command[1])
    except:
        width, length = 4, 5

    if x is 0:
        width_x = [width // 2, width // 2]
        air_x = 1
    else :
        width_x = [0, width * x]
        if x > 0:
            air_x = 1
        else:
            air_x = -1

    if z is 0:
        width_z = [width // 2, width // 2]
        air_z = 1
    else :
        width_z = [0, width * z]
        if z > 0:
            air_z = 1
        else:
            air_z = -1

    print(x, z)
    print(width_x)

    mc.setBlocks(pos.x - width_x[0], pos.y, pos.z - width_z[0],
                 pos.x + width_x[1], pos.y + length, pos.z + width_z[1],
                 Stone)
    mc.setBlocks(pos.x - width_x[0] + air_x, pos.y,
                 pos.z - width_z[0] + air_z,
                 pos.x + width_x[1] - air_x, pos.y + length - 2,
                 pos.z + width_z[1] - air_z,
                 Air)
    mc.setBlocks(pos.x - width_x[0] + air_x, pos.y + length,
                 pos.z - width_z[0] + air_z,
                 pos.x + width_x[1] - air_x, pos.y + length,
                 pos.z + width_z[1] - air_z,
                 Air)

    mc.setBlock(pos.x - width_x[0], pos.y + length + 1,
                pos.z - width_z[0], Stone)
    mc.setBlock(pos.x + width_x[1], pos.y + length + 1,
                pos.z + width_z[1], Stone)
    mc.setBlock(pos.x + width_x[1], pos.y + length + 1,
                pos.z - width_z[0], Stone)
    mc.setBlock(pos.x - width_x[0], pos.y + length + 1,
                pos.z + width_z[1], Stone)
    mc.setBlocks(pos.x, pos.y + 1, pos.z, pos.x, pos.y + 2,
                 pos.z, Air)


def build_building(mc, player_id, pos, command):
    x = pos.x
    y = pos.y
    z = pos.z
    # 공간 초기화
    mc.setBlocks(x - 1, y - 1, z - 1,
                 x + 17 + 1, y + 100, z + 28 + 1, Air)

    ## 1층 만들기
    # 1층 바닥만들기
    mc.setBlocks(x, y - 1, z, x + 14, y - 1, z + 28, Stone)
    mc.setBlocks(x, y - 1, z + 12, x + 17, y - 1, z + 16, Iron_Block)

    # 1층 벽만들기
    # 측면
    mc.setBlocks(x, y, z, x + 13, y + 5, z, Quartz_Block)
    mc.setBlocks(x, y, z + 12, x + 17, y + 5, z + 12, Quartz_Block)
    mc.setBlocks(x, y, z + 16, x + 17, y + 5, z + 16, Quartz_Block)
    mc.setBlocks(x, y, z + 28, x + 13, y + 5, z + 28, Quartz_Block)

    # 앞면
    mc.setBlocks(x + 14, y, z, x + 14, y + 5, z + 11, Bricks)
    mc.setBlocks(x + 14, y + 3, z, x + 14, y + 3, z + 11, Quartz_Block)
    mc.setBlocks(x + 14, y, z + 1, x + 14, y + 4, z + 5, Air)
    mc.setBlocks(x + 14, y, z + 7, x + 14, y + 4, z + 11, Air)
    mc.setBlocks(x + 14, y, z + 17, x + 14, y + 5, z + 28, Bricks)
    mc.setBlocks(x + 14, y + 3, z + 17, x + 14, y + 3, z + 28,
                 Quartz_Block)
    mc.setBlocks(x + 14, y, z + 17, x + 14, y + 4, z + 21, Air)
    mc.setBlocks(x + 14, y, z + 23, x + 14, y + 4, z + 27, Air)

    # 뒷면
    mc.setBlocks(x, y, z + 1, x, y + 5, z + 28, Bricks)

    # 뒷면 유리창
    mc.setBlocks(x, y + 3, z + 2, x, y + 3, z + 4, Glass)
    mc.setBlocks(x, y + 3, z + 24, x, y + 3, z + 26, Glass)
    mc.setBlocks(x, y + 3, z + 13, x, y + 3, z + 15, Glass)

    # 입구 만들기
    mc.setBlocks(x + 17, y, z + 13, x + 17, y + 5, z + 15, Glass)
    mc.setBlocks(x + 17, y + 3, z + 13, x + 17, y + 3, z + 15,
                 Quartz_Block)
    mc.setBlock(x + 17, y, z + 14, Iron_Door_Block, 2)
    mc.setBlock(x + 17, y + 1, z + 14, Iron_Door_Block, 8 + 2)

    # 천장 만들기
    mc.setBlocks(x, y + 5, z, x + 14, y + 5, z + 28, Quartz_Block)

    # 문 만들기
    mc.setBlock(x + 7, y, z + 12, Iron_Door_Block, 1)
    mc.setBlock(x + 7, y + 1, z + 12, Iron_Door_Block, 8+1)
    mc.setBlock(x + 7, y, z + 16, Iron_Door_Block, 1)
    mc.setBlock(x + 7, y + 1, z + 16, Iron_Door_Block, 8+1)

    h = 0

    # 복층 만들기
    rand_num = random.randint(3,20)
    for i in range(rand_num):  # 세 층을 얹음
        time.sleep(1)

        # 바닥 만들기
        h = 5 * i
        mc.setBlocks(x, y + h + 6, z, x + 17, y + h + 6, z + 28,
                     Quartz_Block)
        mc.setBlocks(x, y + h + 6, z, x + 15, y + h + 6, z, Bricks)
        mc.setBlocks(x, y + h + 6, z + 28, x + 15, y + h + 6, z + 28,
                     Bricks)
        mc.setBlocks(x + 1, y + h + 6, z + 1, x + 13, y + h + 6, z + 11,
                     Oak_Wood_Plank)
        mc.setBlocks(x + 1, y + h + 6, z + 18, x + 13, y + h + 6, z + 27,
                     Oak_Wood_Plank)

        # 옆면 만들기
        mc.setBlocks(x, y + h + 7, z, x + 14, y + h + 10, z, Quartz_Block)
        mc.setBlocks(x + 15, y + h + 7, z, x + 17, y + h + 10, z, Bricks)

        mc.setBlocks(x + 1, y + h + 7, z + 11, x + 17, y + h + 10, z + 11,
                     Quartz_Block)

        mc.setBlocks(x + 1, y + h + 7, z + 17, x + 17, y + h + 10, z + 17,
                     Quartz_Block)

        mc.setBlocks(x, y + h + 7, z + 28, x + 14, y + h + 10, z + 28,
                     Quartz_Block)
        mc.setBlocks(x + 15, y + h + 7, z + 28, x + 17, y + h + 10, z + 28,
                     Bricks)

        # 앞면 만들기
        mc.setBlocks(x + 17, y + h + 7, z, x + 17, y + h + 10, z + 28,
                     Bricks)
        mc.setBlocks(x + 17, y + h + 7, z + 12, x + 17, y + h + 10, z + 16,
                     Quartz_Block)

        # 뒷면 만들기
        mc.setBlocks(x, y + h + 6, z + 1, x, y + h + 10, z + 27, Bricks)

        # 앞면 유리창
        mc.setBlocks(x + 17, y + h + 8, z + 2, x + 17, y + h + 9, z + 4,
                     Glass)
        mc.setBlocks(x + 17, y + h + 8, z + 7, x + 17, y + h + 9, z + 9,
                     Glass)
        mc.setBlocks(x + 17, y + h + 7, z + 13, x + 17, y + h + 10, z + 15,
                     Glass)
        mc.setBlocks(x + 17, y + h + 8, z + 19, x + 17, y + h + 9, z + 21,
                     Glass)
        mc.setBlocks(x + 17, y + h + 8, z + 24, x + 17, y + h + 9, z + 26,
                     Glass)

        # 뒷면 유리창
        mc.setBlocks(x, y + h + 8, z + 2, x, y + h + 9, z + 4, Glass)
        mc.setBlocks(x, y + h + 8, z + 24, x, y + h + 9, z + 26, Glass)
        mc.setBlocks(x, y + h + 8, z + 13, x, y + h + 9, z + 15, Glass)

        # 옆면 유리창
        mc.setBlocks(x + 3, y + h + 8, z, x + 5, y + h + 9, z, Glass)
        mc.setBlocks(x + 9, y + h + 8, z, x + 11, y + h + 9, z, Glass)

        mc.setBlocks(x + 3, y + h + 8, z + 28, x + 5, y + h + 9, z + 28,
                     Glass)
        mc.setBlocks(x + 9, y + h + 8, z + 28, x + 11, y + h + 9, z + 28,
                     Glass)

        # 문 만들기
        mc.setBlock(x + 7, y + h + 7, z + 11, Iron_Door_Block, 1)
        mc.setBlock(x + 7, y + h + 8, z + 11, Iron_Door_Block, 8 + 1)
        mc.setBlock(x + 7, y + h + 7, z + 17, Iron_Door_Block, 1)
        mc.setBlock(x + 7, y + h + 8, z + 17, Iron_Door_Block, 8 + 1)

    ## 지붕 설치
    # 지붕 바닥
    h += 5
    mc.setBlocks(x, y + h + 6, z, x + 17, y + h + 6, z + 28, Quartz_Block)
    mc.setBlocks(x, y + h + 6, z, x + 15, y + h + 6, z, Bricks)
    mc.setBlocks(x, y + h + 6, z + 28, x + 15, y + h + 6, z + 28, Bricks)
    mc.setBlocks(x + 1, y + h + 6, z + 1, x + 13, y + h + 6, z + 11,
                 Oak_Wood_Plank)
    mc.setBlocks(x + 1, y + h + 6, z + 18, x + 13, y + h + 6, z + 27,
                 Oak_Wood_Plank)

    mc.setBlocks(x, y + h + 7, z, x + 17, y + h + 8, z + 28, Quartz_Block)
    mc.setBlocks(x + 1, y + h + 8, z + 1, x + 16, y + h + 8, z + 27, Air)

    # 계단 설치
    HighstH = mc.getHeight(x, z)
    for i in range(HighstH):
        if (mc.getBlock(x + 2, i + 1, z + 14) == 0):
            pass
        else:
            mc.setBlocks(x + 2, i + 1, z + 14, x + 6, i + 1, z + 14, Air)
            for ii in range(10):
                if mc.getBlock(x + 2 + ii, i + 1 - ii, z + 14) != Air:
                    break
                else:
                    mc.setBlock(x + 2 + ii, i + 1 - ii, z + 14,
                                Oak_Wood_Stairs, 1)

def highestLand(x, z, mc):
    treelist = [0, 17, 18]  # air, tree, mushroom
    h = mc.getHeight(x, z)
    while (True):
        data = mc.getBlock(x, h - 1, z)
        if data not in treelist:
            print(data)
            return h
        h -= 1

def build_manri(mc, player_id, pos, command):
    x = pos.x
    y = pos.y
    z = pos.z

    length = 100
    mc.postToChat("Start 2 sec later")
    time.sleep(2)

    # 땅에 대한 x 정보를 가져옴
    landListHigh = []
    landListLow = []

    mc.postToChat("Start gathering information of lands")

    for i in range(length):
            # z 좌표 +0~+5에 대해 검사하여 최대의 값을 저장
            zHeight = []

            for j in range(5):
                zHeight.append(highestLand(x + i, z + j, mc))

            h = max(zHeight)
            l = min(zHeight)
            landListHigh.append(h)
            landListLow.append(l)
            print("%d번째 높이 : %d, %d" % (i, h, l))

    mc.postToChat("Start Building Wall")

    # 지금까지 구한 땅에 대한 정보를 바탕으로 흙 세팅
    for i in range(length):
            mc.setBlocks(x + i, landListLow[i], z,
                         x + i, landListHigh[i] + 6, z + 4, Stone)
            mc.setBlocks(x + i, landListHigh[i] + 6, z + 1,
                         x + i, landListHigh[i] + 6, z + 3, Air)
            time.sleep(0.2)

def build_buildings(mc, player_id, pos, command):
    for i in range(5):
        pos.x += 35 * i
        for j in range(5):
            pos.z += 50 * j
            build_building(mc, player_id, pos, command)
            pos.z -= 50 * j
        pos.x -= 35 * i

magic_dict = {
    "도로건설" : build_road,
    "감시탑건설" : build_watchtop,
    "빌딩건설" : build_building,
    "아파트단지건설" : build_buildings,
    "만리장성건설" : build_manri
}