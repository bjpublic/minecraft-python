from mcpi.minecraft import Minecraft
from build import *
import time

#name = input('마인크래프트 사용자 이름 입력: ')
name = 'gasbugs'
mc = Minecraft.create()
player_id = mc.getPlayerEntityId(name)


while(1):
    chatEvent = mc.events.pollChatPosts()
    
    if not chatEvent:
        continue

    ce = chatEvent[0]
    command = ce.message.split()
    
    if command[0] in magic_dict.keys():
        mc.events.pollBlockHits()
        mc.postToChat('select where you want')
        time.sleep(2)
        for hit in mc.events.pollBlockHits():
            if hit.entityId == ce.entityId:
                magic_dict[command[0]](mc, hit.entityId, hit.pos, command[1:])
