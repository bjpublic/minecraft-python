f = open('test.txt', 'w')
f.write("안녕! 파이썬!")
f.close()